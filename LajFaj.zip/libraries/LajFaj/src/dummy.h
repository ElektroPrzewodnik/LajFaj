// Niestety nie da si� stworzy� biblioteki bez pliku �r�d�owego ;)
// Plik ten niweluje ostrze�eni w Arduino IDE o pustej bibliotece