/*************************************************** 
  This is a library for the MCP23008 i2c port expander

  These displays use I2C to communicate, 2 pins are required to  
  interface
  Adafruit invests time and resources providing this open source code, 
  please support Adafruit and open-source hardware by purchasing 
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.  
  BSD license, all text above must be included in any redistribution
 ****************************************************/

#ifndef _LajFaj_H
#define _LajFaj_H
// Don't forget the Wire library
class LajFaj {
public:
  void begin(uint8_t addr);
  void begin(void);

  void pinMode(uint8_t p, uint8_t d);
  void digitalWrite(uint8_t p, uint8_t d);
  void pullUp(uint8_t p, uint8_t d);
  uint8_t digitalRead(uint8_t p);
  uint8_t readGPIO(void);
  int analogRead(uint8_t pin);
  void writeGPIO(uint8_t);

 private:
  uint8_t i2caddr;
  uint8_t read8(uint8_t addr);
  void write8(uint8_t addr, uint8_t data);
};

#define LajFaj_ADDRESS 0x20

// registers
#define LajFaj_IODIR 0x00
#define LajFaj_IPOL 0x01
#define LajFaj_GPINTEN 0x02
#define LajFaj_DEFVAL 0x03
#define LajFaj_INTCON 0x04
#define LajFaj_IOCON 0x05
#define LajFaj_GPPU 0x06
#define LajFaj_INTF 0x07
#define LajFaj_INTCAP 0x08
#define LajFaj_GPIO 0x09
#define LajFaj_OLAT 0x0A


// static const uint8_t A0 = 17;
static const uint8_t A1 = 18;
static const uint8_t A2 = 19;
static const uint8_t A3 = 20;
static const uint8_t A4 = 21;
static const uint8_t A5 = 22;
static const uint8_t A6 = 23;
static const uint8_t A7 = 24;

#endif
