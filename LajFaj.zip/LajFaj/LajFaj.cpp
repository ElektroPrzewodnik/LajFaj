/*************************************************** 
  To jest biblioteka ŁajFaj



  Biblioteka powstała w oparciu o kod firmy Adafruit na licencji BSD.
  
  Adafruit invests time and resources providing this open source code, 
  please support Adafruit and open-source hardware by purchasing 
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.  
  BSD license, all text above' must be included in any redistribution
 ****************************************************/
/*
#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif
*/
#include "Arduino.h"
//#include <Wire.h>
//#include <pgmspace.h>
#include "LajFaj.h"


////////////////////////////////////////////////////////////////////////////////
// RTC_DS1307 implementation

void LajFaj::begin(uint8_t addr) {
  if (addr > 7) {
    addr = 7;
  }
  i2caddr = addr;

  Wire.begin();

  // set defaults!
  Wire.beginTransmission(LajFaj_ADDRESS | i2caddr);
#if ARDUINO >= 100
  Wire.write((byte)LajFaj_IODIR);
  Wire.write((byte)0xFF);  // all inputs
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);
  Wire.write((byte)0x00);	
#else
  Wire.send(LajFaj_IODIR);
  Wire.send(0xFF);  // all inputs
  Wire.send(0x00);
  Wire.send(0x00);
  Wire.send(0x00);
  Wire.send(0x00);
  Wire.send(0x00);
  Wire.send(0x00);
  Wire.send(0x00);
  Wire.send(0x00);
  Wire.send(0x00);	
#endif
  Wire.endTransmission();
  
  // konfiguracja adresowania multiplexera
  pinMode(14, OUTPUT);
  pinMode(13, OUTPUT);
  pinMode(12, OUTPUT);  
}

void LajFaj::begin(void) {
  begin(0);
}

void LajFaj::pinMode(uint8_t p, uint8_t d) {
  if(p == A0 || p == A1 || p == A2 || p == A3 || p == A4 || p == A5 || p == A6 || p == A7)
  ::pinMode(A0,INPUT);
  else{
  uint8_t p_conv=0;
  if(p > 6){
	  
  switch(p){
	case 7: p_conv = 7; break;
	case 8: p_conv = 6; break;
	case 9: p_conv = 5; break;
	case 10: p_conv = 4; break;
	case 11: p_conv = 3; break;
	case 14: p_conv = 2; break;
	case 13: p_conv = 1; break;
	case 12: p_conv = 0; break;
  }
  
  uint8_t iodir;
  
  iodir = read8(LajFaj_IODIR);

  // set the pin and direction
  if (d == INPUT) {
    iodir |= 1 << p_conv; 
  } else {
    iodir &= ~(1 << p_conv);
  }

  // write the new IODIR
  write8(LajFaj_IODIR, iodir);
  
  }else{

  if (p > 14)
    return;

    switch(p){
	case 0: p_conv = 16; break;
	case 1: p_conv = 0; break;
	case 2: p_conv = 2; break;
	case 3: p_conv = 15; break;
	case 4: p_conv = 13; break;
    case 5: p_conv = 12; break;
	case 6: p_conv = 14; break;
  }  
	::pinMode(p_conv,d);
  }
  }
}

uint8_t LajFaj::readGPIO(void) {
  // read the current GPIO input 
  return read8(LajFaj_GPIO);
}

void LajFaj::writeGPIO(uint8_t gpio) {
  write8(LajFaj_GPIO, gpio);
}


void LajFaj::digitalWrite(uint8_t p, uint8_t d) {
  uint8_t gpio;
  uint8_t p_conv=0;
  
  if(p > 6){
	 
  switch(p){
	case 7: p_conv = 7; break;
	case 8: p_conv = 6; break;
	case 9: p_conv = 5; break;
	case 10: p_conv = 4; break;
	case 11: p_conv = 3; break;
	case 14: p_conv = 2; break;
	case 13: p_conv = 1; break;
	case 12: p_conv = 0; break;
  }

  // read the current GPIO output latches
  gpio = readGPIO();

  // set the pin and direction
  if (d == HIGH) {
    gpio |= 1 << p_conv; 
  } else {
    gpio &= ~(1 << p_conv);
  }

  // write the new GPIO
  writeGPIO(gpio);
  }else{

  if (p > 14)
    return;

  switch(p){
	case 0: p_conv = 16; break;
	case 1: p_conv = 0; break;
	case 2: p_conv = 2; break;
	case 3: p_conv = 15; break;
	case 4: p_conv = 13; break;
    case 5: p_conv = 12; break;
	case 6: p_conv = 14; break;
  }  
	::digitalWrite(p_conv,d);
  }
}

void LajFaj::pullUp(uint8_t p, uint8_t d) {
  uint8_t gppu;
  
  // only 8 bits!
  if (p > 7)
    return;

  gppu = read8(LajFaj_GPPU);
  // set the pin and direction
  if (d == HIGH) {
    gppu |= 1 << p; 
  } else {
    gppu &= ~(1 << p);
  }
  // write the new GPIO
  write8(LajFaj_GPPU, gppu);
}

uint8_t LajFaj::digitalRead(uint8_t p) {
  uint8_t p_conv=0;
	  if(p > 6){
	  
  switch(p){
	case 7: p_conv = 7; break;
	case 8: p_conv = 6; break;
	case 9: p_conv = 5; break;
	case 10: p_conv = 4; break;
	case 11: p_conv = 3; break;
  }

  // read the current GPIO
  return (readGPIO() >> p_conv) & 0x1;
  
	  }else{
// only 8 bits!
  if (p > 7)
    return 0;
 switch(p){
	case 0: p_conv = 16; break;
	case 1: p_conv = 0; break;
	case 2: p_conv = 2; break;
	case 3: p_conv = 15; break;
	case 4: p_conv = 13; break;
    case 5: p_conv = 12; break;
	case 6: p_conv = 14; break;
  }  
	  return digitalRead(p_conv);
	  }
}

int LajFaj::analogRead(uint8_t p){
	switch(p){
	case A1: digitalWrite(14,LOW); digitalWrite(13,LOW); digitalWrite(12,LOW); break;
	case A2: digitalWrite(14,HIGH); digitalWrite(13,LOW); digitalWrite(12,LOW); break;
	case A3: digitalWrite(14,LOW); digitalWrite(13,HIGH); digitalWrite(12,LOW); break;
	case A0: digitalWrite(14,HIGH); digitalWrite(13,HIGH); digitalWrite(12,LOW); break;
	case A7: digitalWrite(14,LOW); digitalWrite(13,LOW); digitalWrite(12,HIGH); break;
	case A4: digitalWrite(14,HIGH); digitalWrite(13,LOW); digitalWrite(12,HIGH); break;
	case A6: digitalWrite(14,LOW); digitalWrite(13,HIGH); digitalWrite(12,HIGH); break;	
	case A5: digitalWrite(14,HIGH); digitalWrite(13,HIGH); digitalWrite(12,HIGH); break;	
	}	
	return ::analogRead(A0);
}

uint8_t LajFaj::read8(uint8_t addr) {
  Wire.beginTransmission(LajFaj_ADDRESS | i2caddr);
#if ARDUINO >= 100
  Wire.write((byte)addr);	
#else
  Wire.send(addr);	
#endif
  Wire.endTransmission();
  Wire.requestFrom(LajFaj_ADDRESS | i2caddr, 1);

#if ARDUINO >= 100
  return Wire.read();
#else
  return Wire.receive();
#endif
}


void LajFaj::write8(uint8_t addr, uint8_t data) {
  Wire.beginTransmission(LajFaj_ADDRESS | i2caddr);
#if ARDUINO >= 100
  Wire.write((byte)addr);
  Wire.write((byte)data);
#else
  Wire.send(addr);	
  Wire.send(data);
#endif
  Wire.endTransmission();
}
