/* 
  WifioProtocol.h - virtual IO protocol for the WIFIO board

  Copyright (c) 2015 Ivan Grokhotkov. All rights reserved.
  This file is part of the esp8266 core for Arduino environment.
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef LAJFAJ_PROTOCOL_H
#define LAJFAJ_PROTOCOL_H

#include <stdint.h>
#include "Arduino.h"

#define LajFaj_ADDRESS 0x20
#define LajFaj_IODIR 0x00
#define LajFaj_IPOL 0x01
#define LajFaj_GPINTEN 0x02
#define LajFaj_DEFVAL 0x03
#define LajFaj_INTCON 0x04
#define LajFaj_IOCON 0x05
#define LajFaj_GPPU 0x06
#define LajFaj_INTF 0x07
#define LajFaj_INTCAP 0x08
#define LajFaj_GPIO 0x09
#define LajFaj_OLAT 0x0A

#define MCP_OFFSET 20
#define INPUT_PULLDOWN 0x06

#endif

