#ifndef LAJFAJ_PROTOCOL_H
#define LAJFAJ_PROTOCOL_H

#include <stdint.h>
#include "Arduino.h"

#define LajFaj_ADDRESS 0x20
#define LajFaj_IODIR 0x00
#define LajFaj_IPOL 0x01
#define LajFaj_GPINTEN 0x02
#define LajFaj_DEFVAL 0x03
#define LajFaj_INTCON 0x04
#define LajFaj_IOCON 0x05
#define LajFaj_GPPU 0x06
#define LajFaj_INTF 0x07
#define LajFaj_INTCAP 0x08
#define LajFaj_GPIO 0x09
#define LajFaj_OLAT 0x0A

#define MCP_OFFSET 20
#define INPUT_PULLDOWN 0x06

#endif

