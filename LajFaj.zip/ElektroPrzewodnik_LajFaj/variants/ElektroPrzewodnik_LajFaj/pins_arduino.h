/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis
  Modified for ESP8266 platform by Ivan Grokhotkov, 2014-2015.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  $Id: wiring.h 249 2007-02-03 16:52:51Z mellis $
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#define NUM_DIGITAL_PINS  16
#define NUM_ANALOG_INPUTS 8

static const uint8_t SDA = 4;
static const uint8_t SCL = 5;

static const uint8_t SS   = 2;
static const uint8_t MOSI = 13;
static const uint8_t MISO = 12;
static const uint8_t SCK  = 14;

static const uint8_t LED = 23;

static const uint8_t D0 = 16;
static const uint8_t D1 = 0;
static const uint8_t D2 = 2;
static const uint8_t D3 = 15;
static const uint8_t D4 = 13;
static const uint8_t D5 = 12;
static const uint8_t D6 = 14;

static const uint8_t D7 = 27;
static const uint8_t D8 = 26;
static const uint8_t D9 = 25;
static const uint8_t D10 = 24;
static const uint8_t D11 = 23;
static const uint8_t D12 = 20; // analog switch
static const uint8_t D13 = 21; // analog switch
static const uint8_t D14 = 22; // analog switch

static const uint8_t A0 = 30;
static const uint8_t A1 = 31;
static const uint8_t A2 = 32;
static const uint8_t A3 = 33;
static const uint8_t A4 = 34;
static const uint8_t A5 = 35;
static const uint8_t A6 = 36;
static const uint8_t A7 = 37;

#endif