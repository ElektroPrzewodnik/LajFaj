/*******************************************************************************
  v16.10.22

  LajFaj.cpp - Wiring API implementation for the ElektroPrzewodnik ŁajFaj board

  To jest biblioteka ElektroPrzewodnik ŁajFaj
  Miłego użytkowania :)

  http://youtube.com/ElektroPrzewodnik


  Biblioteka korzysta z fragmentów kodu Adafruit oraz Ivan Grokhotkov.

  -------------------------------------------------------------------
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  BSD license, all text above' must be included in any redistribution
  -------------------------------------------------------------------
  Copyright (c) 2015 Ivan Grokhotkov. All rights reserved.
  This file is part of the esp8266 core for Arduino environment.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
  -------------------------------------------------------------------


 ******************************************************************************/


#include "LajFaj.h"
#include "../../cores/esp8266/twi.h"

namespace lajfaj {
uint8_t read8(uint8_t addr) {
  byte addr_b = (byte) addr;
  twi_writeTo(LajFaj_ADDRESS, &addr_b, 1, true);
  uint8_t data;
  twi_readFrom(LajFaj_ADDRESS, &data, 1, true);
  return data;
}

void write8(uint8_t addr, uint8_t data) {
  byte addr_b = (byte) addr;
  byte data_b = (byte) data;
  twi_writeTo(LajFaj_ADDRESS, &addr_b, 1, false);
  twi_writeTo(LajFaj_ADDRESS, &data_b, 1, true);
}

uint8_t readGPIO(void) {
  return read8(LajFaj_GPIO);
}

void writeGPIO(uint8_t gpio) {
  write8(LajFaj_GPIO, gpio);
}
}

extern "C" void __pinMode(uint8_t pin, uint8_t mode);
extern "C" void __digitalWrite(uint8_t pin, uint8_t val);
extern "C" int  __digitalRead(uint8_t pin);
// extern "C" void __attachInterrupt(uint8_t pin, voidFuncPtr handler, int mode); // to be implemented...
// extern "C" void __detachInterrupt(uint8_t pin); // to be implemented...
extern "C" int  __analogRead(uint8_t pin);


extern "C" void pinMode2(uint8_t pin, uint8_t mode) {
  if (pin < 30)
    if (pin > (MCP_OFFSET - 1)) {
      pin -= MCP_OFFSET;
      uint8_t iodir;

      iodir = lajfaj::read8(LajFaj_IODIR);

      if (mode == OUTPUT)
        iodir &= ~(1 << pin);
      else
        iodir |= (1 << pin);

      lajfaj::write8(LajFaj_IODIR, iodir);

      iodir = lajfaj::read8(LajFaj_GPPU);
      if (mode == INPUT_PULLUP)
        iodir |= (1 << pin);
      else
        iodir &= ~(1 << pin);
      lajfaj::write8(LajFaj_GPPU, iodir);
    } else
      __pinMode(pin, mode);
}


extern "C" void digitalWrite2(uint8_t pin, uint8_t value) {
  uint8_t gpio;

  if (pin > (MCP_OFFSET - 1)) {
    pin -= MCP_OFFSET;
    gpio = lajfaj::readGPIO();

    if (value == HIGH)
      gpio |= 1 << pin;
    else
      gpio &= ~(1 << pin);

    lajfaj::writeGPIO(gpio);
  } else
    __digitalWrite(pin, value);
}


extern "C" int digitalRead2(uint8_t pin) {
  if (pin > (MCP_OFFSET - 1))
  {
    pin -= MCP_OFFSET;
    return (~(lajfaj::readGPIO() >> pin) & 1);
    //return (lajfaj::readGPIO() >> pin);
  }
  else
    return __digitalRead(pin);
}


extern "C" int analogRead2(uint8_t pin) {
  switch (pin) {
    case A1: digitalWrite2(22, LOW); digitalWrite2(21, LOW); digitalWrite2(20, LOW); break;
    case A2: digitalWrite2(22, HIGH); digitalWrite2(21, LOW); digitalWrite2(20, LOW); break;
    case A3: digitalWrite2(22, LOW); digitalWrite2(21, HIGH); digitalWrite2(20, LOW); break;
    case A0: digitalWrite2(22, HIGH); digitalWrite2(21, HIGH); digitalWrite2(20, LOW); break;
    case A7: digitalWrite2(22, LOW); digitalWrite2(21, LOW); digitalWrite2(20, HIGH); break;
    case A4: digitalWrite2(22, HIGH); digitalWrite2(21, LOW); digitalWrite2(20, HIGH); break;
    case A6: digitalWrite2(22, LOW); digitalWrite2(21, HIGH); digitalWrite2(20, HIGH); break;
    case A5: digitalWrite2(22, HIGH); digitalWrite2(21, HIGH); digitalWrite2(20, HIGH); break;
    default: break;
  }

  return __analogRead(0) == 0 ? 0 : __analogRead(0) - 1;
}


void initVariant() {
  pinMode(SDA, INPUT_PULLUP);
  pinMode(SCL, INPUT_PULLUP);
  //twi_setClock(400000);

  //uint8_t data = LajFaj_IODIR;
  twi_init(SDA, SCL);
  //twi_writeTo(LajFaj_ADDRESS, &data, 1, true);
  //data = 0xFF;
  //twi_writeTo(LajFaj_ADDRESS, &data, 1, true);
  //data = 0x00;
  //for(int i=0;i<10;i++) twi_writeTo(LajFaj_ADDRESS, &data, 1, true);

  pinMode2(20, OUTPUT);
  pinMode2(21, OUTPUT);
  pinMode2(22, OUTPUT);
}

extern void pinMode(uint8_t pin, uint8_t mode) __attribute__ ((weak, alias("pinMode2")));
extern void digitalWrite(uint8_t pin, uint8_t mode) __attribute__ ((weak, alias("digitalWrite2")));
extern int digitalRead(uint8_t pin) __attribute__ ((weak, alias("digitalRead2")));
extern int analogRead(uint8_t pin) __attribute__ ((weak, alias("analogRead2")));
