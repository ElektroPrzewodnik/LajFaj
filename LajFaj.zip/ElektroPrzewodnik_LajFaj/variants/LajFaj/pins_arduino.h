/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis
  Modified for ESP8266 platform by Ivan Grokhotkov, 2014-2015.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  $Id: wiring.h 249 2007-02-03 16:52:51Z mellis $
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#define NUM_DIGITAL_PINS  16
#define NUM_ANALOG_INPUTS 8


#define LajFaj_ADDRESS 0x20
#define LajFaj_IODIR 0x00
#define LajFaj_IPOL 0x01
#define LajFaj_GPINTEN 0x02
#define LajFaj_DEFVAL 0x03
#define LajFaj_INTCON 0x04
#define LajFaj_IOCON 0x05
#define LajFaj_GPPU 0x06
#define LajFaj_INTF 0x07
#define LajFaj_INTCAP 0x08
#define LajFaj_GPIO 0x09
#define LajFaj_OLAT 0x0A


static const uint8_t SDA = 4;
static const uint8_t SCL = 5;

static const uint8_t SS   = 2;
static const uint8_t MOSI = 13;
static const uint8_t MISO = 12;
static const uint8_t SCK  = 14;

static const uint8_t LED = 3;
static const uint8_t D0 = 16;
static const uint8_t D1 = 0;
static const uint8_t D2 = 2;
static const uint8_t D3 = 15;
static const uint8_t D4 = 13;
static const uint8_t D5 = 12;
static const uint8_t D6 = 14;
static const uint8_t D7 = 7;
static const uint8_t D8 = 6;
static const uint8_t D9 = 5;
static const uint8_t D10 = 4;
static const uint8_t D11 = 3;
static const uint8_t D12 = 0;
static const uint8_t D13 = 1;
static const uint8_t D14 = 2;

static const uint8_t A0 = 17;
static const uint8_t A1 = 18;
static const uint8_t A2 = 19;
static const uint8_t A3 = 20;
static const uint8_t A4 = 21;
static const uint8_t A5 = 22;
static const uint8_t A6 = 23;
static const uint8_t A7 = 24;

#endif