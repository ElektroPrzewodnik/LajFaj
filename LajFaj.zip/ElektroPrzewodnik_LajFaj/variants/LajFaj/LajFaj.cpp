/* 
  LajFaj.cpp - Wiring API implementation for the ElektroPrzewodnik ŁajFaj board

  Copyright (c) 2015 Ivan Grokhotkov. All rights reserved.
  This file is part of the esp8266 core for Arduino environment.
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/***************************************************
  To jest biblioteka ElektroPrzewodnik ŁajFaj
  Biblioteka powstała w oparciu o kod firmy Adafruit na licencji BSD.
  Miłego użytkowania :)

  http://youtube.com/ElektroPrzewodnik
  
  -------------------------------------------------------------------
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  BSD license, all text above' must be included in any redistribution
 ****************************************************/

#include "wiring_private.h"
#include "LajFaj.h"
#include <Wire.h>

namespace LajFaj {
    
	uint8_t readGPIO(void) {
		return read8(LajFaj_GPIO);
	}

	void writeGPIO(uint8_t gpio) {
		write8(LajFaj_GPIO, gpio);
	}
    
	uint8_t read8(uint8_t addr) {
	  Wire.beginTransmission(LajFaj_ADDRESS);
	#if ARDUINO >= 100
	  Wire.write((byte)addr);
	#else
	  Wire.send(addr);
	#endif
	  Wire.endTransmission();
	  Wire.requestFrom(LajFaj_ADDRESS, 1);

	#if ARDUINO >= 100
	  return Wire.read();
	#else
	  return Wire.receive();
	#endif
	}

	void write8(uint8_t addr, uint8_t data) {
	  Wire.beginTransmission(LajFaj_ADDRESS);
	#if ARDUINO >= 100
	  Wire.write((byte)addr);
	  Wire.write((byte)data);
	#else
	  Wire.send(addr);
	  Wire.send(data);
	#endif
	  Wire.endTransmission();
	}	
} // namespace wifio


extern "C" void __pinMode(uint8_t pin, uint8_t mode);
extern "C" void __digitalWrite(uint8_t pin, uint8_t val);
extern "C" int  __digitalRead(uint8_t pin);
//extern "C" void __analogWrite(uint8_t pin, int val);
// extern "C" void __attachInterrupt(uint8_t pin, voidFuncPtr handler, int mode);
// extern "C" void __detachInterrupt(uint8_t pin);
extern "C" void __initPins();
extern "C" int  __analogRead(uint8_t pin);


extern "C" void pinMode(uint8_t pin, uint8_t mode){
   if (pin == A0 || pin == A1 || pin == A2 || pin == A3 || pin == A4 || pin == A5 || pin == A6 || pin == A7)
    __pinMode(A0, INPUT);
  else {
    if (pin < 8) {
      uint8_t iodir;
      iodir = LajFaj::read8(LajFaj_IODIR);

      if (mode == INPUT)
        iodir |= 1 << pin;
      else
        iodir &= ~(1 << pin);

      LajFaj::write8(LajFaj_IODIR, iodir);
    } else
      __pinMode(pin, mode);
  }
}


extern "C" void digitalWrite(uint8_t pin, uint8_t value) {
	uint8_t gpio;

  if (pin < 8) {
    gpio = LajFaj::readGPIO();

    if (value == HIGH)
      gpio |= 1 << pin;
    else
      gpio &= ~(1 << pin);

    LajFaj::writeGPIO(gpio);
  } else
    __digitalWrite(pin, value);
}

extern "C" int digitalRead(uint8_t pin) {
  if (pin < 8)
    return (LajFaj::readGPIO() >> pin) & 0x1;
  else
    return __digitalRead(pin);
}


extern "C" int analogRead(uint8_t pin) {
   switch (pin) {
    case A1: digitalWrite(14, LOW); digitalWrite(13, LOW); digitalWrite(12, LOW); break;
    case A2: digitalWrite(14, HIGH); digitalWrite(13, LOW); digitalWrite(12, LOW); break;
    case A3: digitalWrite(14, LOW); digitalWrite(13, HIGH); digitalWrite(12, LOW); break;
    case A0: digitalWrite(14, HIGH); digitalWrite(13, HIGH); digitalWrite(12, LOW); break;
    case A7: digitalWrite(14, LOW); digitalWrite(13, LOW); digitalWrite(12, HIGH); break;
    case A4: digitalWrite(14, HIGH); digitalWrite(13, LOW); digitalWrite(12, HIGH); break;
    case A6: digitalWrite(14, LOW); digitalWrite(13, HIGH); digitalWrite(12, HIGH); break;
    case A5: digitalWrite(14, HIGH); digitalWrite(13, HIGH); digitalWrite(12, HIGH); break;
  }
  return __analogRead(A0);
}

/*
extern "C" void analogWrite(uint8_t pin, int value) {
  if (pin >= ESP_PINS_OFFSET) {
    __analogWrite(pin - ESP_PINS_OFFSET, value);
  }
  else {
    wifio::analogWrite(pin, value);
  }
}
*/


/*
// DO ZROBIENIA!
void ElektroPrzewodnik::pullUp(uint8_t p, uint8_t d) {
  uint8_t gppu;

  gppu = read8(LajFaj_GPPU);
  // set the pin and direction
  if (d == HIGH)
    gppu |= 1 << p;
  else
    gppu &= ~(1 << p);

  // write the new GPIO
  write8(LajFaj_GPPU, gppu);
}
*/

void initPins() {
  Wire.begin();
  pinMode(14, OUTPUT);
  pinMode(13, OUTPUT);
  pinMode(12, OUTPUT);
}
